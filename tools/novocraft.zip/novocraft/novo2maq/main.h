#ifndef LH3_MAIN_H
#define LH3_MAIN_H

#ifdef __cplusplus
extern "C" {
#endif
	int maq_novo2maq(int argc, char *argv[]);   /* in novo2maq.cc */
#ifdef __cplusplus
}
#endif

#endif
