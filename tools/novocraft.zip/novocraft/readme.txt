(C)  NovoCraft Technologies Sdn Bhd

You need a valid current license to use Novoalign Version 4 and later. You can purchase a license 
or request a trial license from http://www.novocraft.com/buy-now/

Novoalign V3 and earlier can be used by educational and non-profit organisations without a license 
for internal use only. Some features are disabled if a valid license file is not found.

For commercial licenses and support contracts contact sales@novocraft.com

CHANGE LOG

Novoalign V4.02.03, Novomethyl V1.07, Novosort V2.02.00
-------------------------------------------------------
Novoalign
       1. Fix assert failure in CIGAR generation routine.

Novoalign V4.02.02, Novomethyl V1.07, Novosort V2.02.00
-------------------------------------------------------
Novoalign
       1. Reruns of Novoalign V4 could be discordant. Differences were seen in reads
          multi-mapped to repeats with very low alignment scores and
          with MAPQ <= 1 and affected the AM & SM single end quality tags but could
          also change MAPQ between 0&1.
       2. Fix: When using --tune Hiseqx the polyclonal settings were misreported, showing as -p 1,4 when it was -p 4,20
       3. Fix: When using --tags MC the Mate CIGAR tag was not being added to chimeric supplementary alignments.

Novoalign V4.02.01, Novomethyl V1.07, Novosort V2.02.00
-------------------------------------------------------
Novoalign
       1. Add option to disable generation of M5 checksums for @SQ records.
           --addM5 [on|off]   Default is On.
Novoindex
       1. Adjust default index k&s for better performance on Human reference genome. 
          Default now builds a k=15, s=2 index rather than a 14/2.
Novoutil
       1. Add function 'addFastaM5' to add M5 and LN metadata tags to fasta headers.

Novoalign V4.02.00, Novomethyl V1.07, Novosort V2.02.00
-------------------------------------------------------
Novoalign
       1. Fix: Novoalign paired end chimera mode could produce invalid alignments 
          across circular chromosome junctions if read sequence had N's at the junction
       2. Fix: novoalign: src/rptSAM.cc:775: void rptSAM::rptcigar(): Assertion `tgt[tposn] != '\0'' failed.
Novosort
       1. Performance tuning of mark duplicates code. This should reduce run time on high core count servers.
Novoutil
       1. Fix: Splitbed function could produce bed file with coordinates outside chromosome size when 
          using the --add option. To fix we now have an option (--sam) to input a SAM format header 
          file and then extract sequence lengths from the @SQ records.

Novoalign V4.01.00, Novomethyl V1.07, Novosort V2.01.02
-------------------------------------------------------
Novoalign
       1. In base quality calibration (-k) limit maximum base quality to 60. (GATK limit)
       2. Fix: When compiling with gcc 7.4, BAM output format shifted base qualities one to the right. This only 
          happened on our development system after upgrading gcc and isn't in any official releases.
       3. Increased sensitivity of chimeric read mapping by removing structural variation penalty from calculation.
Novosort
       1. Add option --callableRegions to write a bed file of callable regions. "novosort --help" for more details.
Novoutil
       1. Added function splitbed that divides a bed file into multiple files of approximate equal size. We have used this with WGS
          sequencing and novosort --callableregions to create per core region bed files for variant calling that are equal size.
          For WES we use target capture region bed files as input rather than the callable regions file from Novosort
          "novoalign splitbed --help" for details

Novoalign V4.00.01, Novomethyl V1.07, Novosort V2.01.01
-------------------------------------------------------
Novoalign
      1. Fix: When using alternate scaffolds the mate CIGAR tag (enable with --tags MC ) could have the CIGAR of a supplementary alignment rather than the primary alignment.

Novoalign V4.00.00, Novomethyl V1.07, Novosort V2.01.01
-------------------------------------------------------
Novoalign
      1. Fix: If Novoalign is given empty input file it wasn't writing BAM headers and exited with an error status. 
         This change will produce a valid SAM file with headers only and exit with normal status.
	  2. When several alt-scaffold alignments have the same best alignment score (and better than main chromosome alignments) the primary alignment is now selected randomly from the alt-scaffold alignments.

Release Candidate 1 Novoalign V4.00.RC1-20190917, Novomethyl V1.07, Novosort V2.01.01
---------------------------------------------------------------------------
Novoalign
     1. Fix: Novoalign would crash with Interrupt..4 on computers without SSE4.1
     2. Fix: Novoalign paired end could slow if one read had trimmed to a short length due to low quality bases and the other was adapter trimmed.
     3. Add option --2NoSQ to have SEQ and QUAL set to '*' on secondary alignments.
     4. Fix: Supplementary alignments in BAM output format leaked memory.
     5. Fix: assert failure in CIGAR routine triggered by reads overlapping the ends of a reference sequence.
     6. Any 5' trimming (-5 option) is now done after 3' adapter trimming in order to ensure adapter dimers are trimmed.
     7. Fix: --trim3hp option was leaving one bp of homopolymer sequence.
     8. --trim3hp now accepts IUPAC R which will trim 3' mixed AG sequence. This may be useful for RNA to trim Poly A tails where read has degraded to G's with high base quality.
     9. Increased mismatch allowance for adapter trimming on single end reads. Allow ~1 mismatch per 6 matches depending on read base qualities.
    10. Fix: When using alt-scaffolds SAM file could fail Picard ValidateSamFile due to RNEXT,PNEXT of improper pairs referencing supplementary rather than primary alignment.
    11. In BAM output mode the bin attribute was not set resulting in a bad bai index being generated by novosort
Novosort
     1. Updated the default code for parsing lane,tile,X&Y from fastq headers to skip trailing UMI
                @Instrument:RunID:FlowCellID:Lane:Tile:X:Y:UMI
        Lane,tile,x*y are used to classify optical duplicates and estimate library size, they do not affect which reads are marked as duplicates.


Pre-Release Novoalign V4.0.Pre-20190805, Novomethyl V1.07, Novosort V2.01.00
---------------------------------------------------------------------------
Novoalign
      1. Added option to create SAM BC tag from Illumina header. If you have an Illumina read header like
         @A00615:18:H7T32DRXX:1:2101:3658:1000 1:N:0:TGTACCGT 
         and add option --tags BC then novoalign extracts barcode from read header and adds tag  BC:Z:TGTACCGT to the SAM records.
      2. Add BAM output format option. This may give better performance than piping to 'samtools view' on high core count systems.
              -o BAM [0-9] ["@RG..."]
         You can set the compression level, default is 4. We suggest 0 if piping to novosort.
      2. Fix: Reruns were non-concordant due to changes in "random" selection of alignments 
         when reporting multi-mapped reads.
      3. Fix: --tune V3 was setting -H 2 when V3 default was -H off
      4. Fix: Paired end adapter trimming would QC pairs with adapters.
      5. Fix: Ability to map reads that overlap the end of a reference sequence was reduced in V4 vs V3
      6. In Bi-Seq mode setting --tune V3 now sets unconverted cytosine penalty to zero.
      7. Fix: In alternate scaffold mode multiple alignments could be reported per scaffold even when using -r All 1 or -r Random.
      8. Fix: With --pechimera On (new default) and relatively high gap extend + match reward (>= 10 for 150bp read) Novoalign could 
         get an assert failure.
      9. In novoindex allow up to 5 IUPAC ambiguous dinucleotide codes per kmer. Index must be rebuilt for this to take effect.
     10. Fix: Soft clipping with rewards for realignments that extended to the end of the read sometimes failed to clip leaving long inserts in CIGAR.
Novosort
      1. Fix: The novosort with V4 had had some performance related changes but we failed to update the version number.
      2. Fix: If input BAMs had no unmapped reads when marking duplicates then the last signature group was not output.
      3. Fix: If using the --uniquetags options and a read doesn't have the tag then the tag value from previous read was used.
      4. Add --UMI option to use UMI tag from Illumina header in read signature.
         Read headers in format
             @Instrument:RunID:FlowCellID:Lane:Tile:X:Y:UMI 
         extract the UMI and use it in the read signature.




